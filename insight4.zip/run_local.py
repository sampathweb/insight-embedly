from app import create_app


if __name__ == '__main__':
    env = 'dev'
    dbcon = 'postgresql://dbadmin:2Insight!@insight-ramesh-dw.cniqeoxrupxt.us-west-2.redshift.amazonaws.com:5439/dev'
    app = create_app('app.settings.%sConfig' % env.capitalize(), env, dbcon)
    app.run(host='0.0.0.0', port=5000, debug=True)
